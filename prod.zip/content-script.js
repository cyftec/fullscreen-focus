// dev/@libs/constants.ts
var TOP_EXIT_ZONE_PX = 5;
var TOP_ENTER_ZONE_PX = 28;
var EXTENSION_INIT_FLAG = "__fullscreen-focus";

// dev/content-script.ts
var win = window;
var isAltKey = (event) => event.key === "Alt" || event.code === "AltLeft" || event.code === "AltRight";
if (!win[EXTENSION_INIT_FLAG]) {
  win[EXTENSION_INIT_FLAG] = true;
  let wantFullscreen = null;
  let lastClientY = 0;
  const applyPointerY = (clientY, blockEnterFullscreen) => {
    let next = wantFullscreen;
    if (next === null) {
      next = clientY > TOP_EXIT_ZONE_PX;
    } else if (next && clientY <= TOP_EXIT_ZONE_PX) {
      next = false;
    } else if (!next && clientY > TOP_ENTER_ZONE_PX) {
      next = true;
    } else {
      return;
    }
    if (blockEnterFullscreen && next)
      return;
    if (next === wantFullscreen)
      return;
    wantFullscreen = next;
    chrome.runtime.sendMessage({ wantFullscreen: next }).catch(() => {});
  };
  window.addEventListener("pointermove", (event) => {
    lastClientY = event.clientY;
    applyPointerY(event.clientY, event.altKey);
  }, { capture: true, passive: true });
  window.addEventListener("keyup", (event) => {
    if (!isAltKey(event))
      return;
    applyPointerY(lastClientY, false);
  }, { capture: true });
}
